package csc.TwitterProducer;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;



import java.util.Properties;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;
import twitter4j.FilterQuery;
import twitter4j.StallWarning;
import twitter4j.Status;
import twitter4j.StatusDeletionNotice;
import twitter4j.StatusListener;
import twitter4j.Twitter;
import twitter4j.TwitterFactory;
import twitter4j.TwitterStream;
import twitter4j.TwitterStreamFactory;
import twitter4j.conf.ConfigurationBuilder;


public class App {
	public static void main(String[] args)
	{
		/* ConfigurationBuilder cb = new ConfigurationBuilder();
		 cb.setDebugEnabled(true)
		    .setOAuthConsumerKey("K1qBbRE8NSzjWp5MrPg4RHbHe")
			   .setOAuthConsumerSecret("J0poetqWsK8bjkg1Xa5eoNC6qKXt1uiCBEbfspbhmazGS0gx6h")
			   .setOAuthAccessToken("2836842002-CBykTqc6i2JA4ju70jeaoXovsr6pwR5274maSW3")
			   .setOAuthAccessTokenSecret("jfHkw1s3YqIsBxz8wJXwodb7ys9o7vIg3rHDud7caWrTT");
		 
		 	  TwitterStream twitterStream = new TwitterStreamFactory(cb.build()).getInstance();
		StatusListener listener = new StatusListener()
		{
	       
	        public void onDeletionNotice(StatusDeletionNotice statusDeletionNotice) {}
	        public void onTrackLimitationNotice(int numberOfLimitedStatuses) {}
	        public void onException(Exception ex) {
	            ex.printStackTrace();
	        }
			public void onScrubGeo(long arg0, long arg1) {
				// TODO Auto-generated method stub
				
			}
			public void onStallWarning(StallWarning arg0) {
				// TODO Auto-generated method stub
				
			}
			public void onStatus(Status status) {
				// TODO Auto-generated method stub
				 System.out.println(status.getUser().getName() + " : " + status.getText());
			}
	    };
	    			
	    FilterQuery fq = new FilterQuery();
	    String keywords[] = {"Timesnow"};

	    fq.track(keywords);

	    twitterStream.addListener(listener);
	    twitterStream.filter(fq);     */
	    
	    Properties props = new Properties();
        props.put("metadata.broker.list", "localhost:9092");
        //props.put("producer.type", "sync");
        props.put("serializer.class", "kafka.serializer.StringEncoder");
        props.put("request.required.acks", "1");
       
 
        ProducerConfig config = new ProducerConfig(props);
 
        Producer<String, String> producer = new Producer<String, String>(config);
 
        SimpleDateFormat sdf = new SimpleDateFormat();
        KeyedMessage<String, String> message =new KeyedMessage<String, String>("test","Test message from java program " + sdf.format(new Date()));
        producer.send(message);
        System.out.println(" Message Sent ");
        producer.close();
			
			 	    
			 	   //twitterStream.sample();
	            
	}
}
